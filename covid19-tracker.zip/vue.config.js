module.exports = {
  "transpileDependencies": [
    "vuetify"
  ]
}
